from view import ListaView

if __name__ == "__main__":
    ListaView().run()
